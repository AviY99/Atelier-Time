ATELIER TIME — GOOGLE PLAY APPROVED ASSETS

Current app: Stable 12 / D-141.

Folders:
01_Store_Icon: approved 512x512 app icon converted from the existing launcher art.
02_Locked_Feature_Graphic: first ORIGINAL promotional graphic (1024x500). DO NOT EDIT.
03_Phone_Screenshots_Upload_In_This_Order: eight 1080x1920 PNGs in the user's approved order.
04_Original_10_Screens_Backup: the complete original ten screenshots archive for recovery; About and early Class Timer session are omitted from the eight store gallery only.

Google Play Console upload has NOT been performed.
Only documentation and approval hashes exist in GitHub currently; these image binaries are in this archive attachment.
Do not modify the app binary or frozen Stable12 branch.
